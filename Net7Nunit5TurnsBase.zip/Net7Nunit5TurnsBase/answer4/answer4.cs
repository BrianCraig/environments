namespace Answer4;
// DON'T SHOW NAMESPACES IN YOUR ANSWERS
// THIS LINE SHOULD NOT BE IN THE ANSWER
// THIS SHOULD BE A SEVERE ERROR

using System;

class Program
{
  public static void Main(string[] args)
  {
    Console.WriteLine("Turn 4 implementation");
  }
}
