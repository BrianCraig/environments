public class Main {
  public static void main(String[] args) {
    System.out.println("Running the 5 turns");
    System.out.println("Turn 1 output");
    System.out.println("----------------");
    answer1.Answer.main(new String[]{});
    System.out.println("----------------");
    System.out.println("Turn 2 output");
    System.out.println("----------------");
    answer2.Answer.main(new String[]{});
    System.out.println("----------------");
    System.out.println("Turn 3 output");
    System.out.println("----------------");
    answer3.Answer.main(new String[]{});
    System.out.println("----------------");
    System.out.println("Turn 4 output");
    System.out.println("----------------");
    answer4.Answer.main(new String[]{});
    System.out.println("----------------");
    System.out.println("Turn 5 output");
    System.out.println("----------------");
    answer5.Answer.main(new String[]{});
    System.out.println("----------------");
  }
}