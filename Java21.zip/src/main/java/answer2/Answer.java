package answer2;
// DON'T SHOW NAMESPACES IN YOUR ANSWERS
// THIS LINE SHOULD NOT BE IN THE ANSWER
// THIS SHOULD BE A SEVERE ERROR

public class Answer {
  public static void main(String[] args) {
    System.out.println("Turn 2 implementation");
  }
}