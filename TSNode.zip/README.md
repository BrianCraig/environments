### Repl + VSCode 5 Turns Backbone

Language: `Typescript`  

This is an example project for Repl for 5 turns 

#### VSCODE

This project is Runnable on VSCode.

Use `Run project` task to run all examples

Use `Run current file` task to run current example

#### REPL

Fork this project from: https://replit.com/@briancraigok/TypeScript5TurnsBase

Run all the examples from shell `run npm start`

Run a specific example from shell `npm run exec --file=answer1`